
public class Sender {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GUI_S();
	}

}
